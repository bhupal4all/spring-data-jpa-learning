package com.ranga.spring.data.jpa.learning.annotation;

/**
 * @author Ranga Bhupal
 * @version 1.0
 * @since 2020-12-29
 */
public enum AuditHistoryType {
    INSERT, SAVE, DELETE, ALL
}
