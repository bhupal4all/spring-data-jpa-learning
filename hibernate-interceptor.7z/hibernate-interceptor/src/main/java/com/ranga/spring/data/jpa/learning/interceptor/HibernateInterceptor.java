package com.ranga.spring.data.jpa.learning.interceptor;

import com.ranga.spring.data.jpa.learning.SpringContextUtil;
import com.ranga.spring.data.jpa.learning.annotation.AuditHistory;
import com.ranga.spring.data.jpa.learning.annotation.AuditHistoryIdentifier;
import com.ranga.spring.data.jpa.learning.annotation.AuditHistoryIgnore;
import com.ranga.spring.data.jpa.learning.annotation.AuditHistoryType;
import com.ranga.spring.data.jpa.learning.entity.Books;
import com.ranga.spring.data.jpa.learning.service.BooksService;
import org.apache.logging.log4j.util.Strings;
import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;
import org.javers.core.Changes;
import org.javers.core.Javers;
import org.javers.core.JaversBuilder;
import org.javers.core.diff.Change;
import org.javers.core.diff.Diff;
import org.javers.core.diff.ListCompareAlgorithm;
import org.javers.core.diff.changetype.container.ArrayChange;
import org.javers.core.diff.changetype.container.ContainerElementChange;
import org.javers.core.diff.changetype.container.ElementValueChange;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Ranga Bhupal
 * @version 1.0
 * @since 2020-12-29
 */
@Component
public class HibernateInterceptor extends EmptyInterceptor {


    Javers javers = JaversBuilder.javers().withListCompareAlgorithm(ListCompareAlgorithm.AS_SET).build();
    BooksService booksService;
    HibernateInterceptorProperties properties;
    Map<Class, List> ignorePropertiesMap = new HashMap<>();
    Map<Class, Field> identifierMap = new HashMap<>();


    private BooksService getBooksService() {
        if (booksService == null) {
            booksService = SpringContextUtil.getApplicationContext().getBean(BooksService.class);
        }

        return booksService;
    }

    private HibernateInterceptorProperties getProperties() {
        if (properties == null) {
            properties = SpringContextUtil.getApplicationContext().getBean(HibernateInterceptorProperties.class);
        }
        return properties;
    }

    @Override
    public boolean onSave(Object entity,
                          Serializable id,
                          Object[] state,
                          String[] propertyNames,
                          Type[] types) {
        if (isAuditHistoryEnabledFor(entity, AuditHistoryType.SAVE)) {
            writeHistory(entity, state, null, propertyNames);
        }

        return super.onSave(entity, id, state, propertyNames, types);
    }

    @Override
    public boolean onFlushDirty(Object entity,
                                Serializable id,
                                Object[] currentState,
                                Object[] previousState,
                                String[] propertyNames,
                                Type[] types) {
        if (isAuditHistoryEnabledFor(entity, AuditHistoryType.SAVE)) {
            writeHistory(entity, currentState, previousState, propertyNames);
        }

        return super.onFlushDirty(entity, id, currentState, previousState, propertyNames, types);
    }

    @Override
    public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
        if (isAuditHistoryEnabledFor(entity, AuditHistoryType.DELETE)) {
            writeHistory(entity, null, state, propertyNames);
        }

        super.onDelete(entity, id, state, propertyNames, types);
    }

    private boolean isAuditHistoryEnabled(Object entity) {
        return AnnotationUtils.isAnnotationDeclaredLocally(AuditHistory.class, entity.getClass());
    }

    private boolean isAuditHistoryEnabledFor(Object entity, AuditHistoryType requiredAuditHistoryType) {
        boolean isEnabled = false;
        if (isAuditHistoryEnabled(entity)) {
            AuditHistoryType[] types = entity.getClass().getAnnotation(AuditHistory.class).value();
            isEnabled = Arrays.stream(types)
                    .anyMatch(type -> type.equals(requiredAuditHistoryType) || type.equals(AuditHistoryType.ALL));
        }

        return isEnabled;
    }

    private Object getEntityAuditIdentifier(Object entity, String[] propertyNames) {
        Object returnValue = null;

        if (!identifierMap.containsKey(entity.getClass())) {
            List<Field> identifierFields = Arrays.stream(entity.getClass().getDeclaredFields())
                    .filter(field -> AnnotationUtils.getAnnotation(field, AuditHistoryIdentifier.class) != null)
                    .collect(Collectors.toList());
            if (!identifierFields.isEmpty()) {
                identifierMap.put(entity.getClass(), identifierFields.get(0));
            }
        }

        try {
            Field identifierField = identifierMap.get(entity.getClass());
            if (identifierField != null) {
                returnValue = identifierField.get(entity);
            }
        } catch (Exception excp) {
            System.err.println(excp);
            // TODO: Exception Handling
        }

        return returnValue;
    }

    private List getAuditHistoryIgnoreProperties(Object entity) {
        List<String> ignoreProperties = new ArrayList<>();

        if (!ignorePropertiesMap.containsKey(entity.getClass())) {
            ignoreProperties = Arrays.stream(entity.getClass().getDeclaredFields())
                    .filter(field -> AnnotationUtils.getAnnotation(field, AuditHistoryIgnore.class) != null)
                    .map(field -> field.getName())
                    .collect(Collectors.toList());
            ignorePropertiesMap.put(entity.getClass(), ignoreProperties);
        }

        return ignoreProperties;
    }

    private void writeHistory(Object entity, Object[] currentState, Object[] previousState, String[] propertyNames) {
        List<String> changeStrings = new ArrayList<>();

        List auditHistoryIgnoreProperties = getAuditHistoryIgnoreProperties(entity);
        Object identifier = getEntityAuditIdentifier(entity, propertyNames);

        if (previousState == null && currentState != null) {
            changeStrings.add(String.format(getProperties().getNewFormat(), identifier));
        } else if (previousState != null && currentState == null) {
            changeStrings.add(String.format(getProperties().getDeleteFormat(), identifier));
        } else {
            Diff compare = javers.compare(previousState, currentState);
            Changes changes = compare.getChanges();
            for (int i = 0; i < changes.size(); i++) {
                Change change = changes.get(i);

                if (change instanceof ArrayChange) {
                    ArrayChange ac = (ArrayChange) change;
                    List<ContainerElementChange> arrayChanges = ac.getChanges();

                    for (int idx = 0; idx < arrayChanges.size(); idx++) {
                        ElementValueChange ele = (ElementValueChange) arrayChanges.get(idx);
                        String propertyName = propertyNames[ele.getIndex()];

                        if (!auditHistoryIgnoreProperties.contains(propertyName)) {
                            String message = String.format(getProperties().getModifiedFormat(),
                                    propertyName,
                                    ele.getLeftValue(),
                                    ele.getRightValue());
                            changeStrings.add(message);
                        }
                    }
                }
            }
        }

        getBooksService().createHistory(
                ((Books) entity).getId(),
                Strings.join(changeStrings, '\n')
        );

    }
}
